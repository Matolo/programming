namespace assignment10
{
    public partial class Form1 : Form
    {
        const int basicPrice = 12;
        public Form1()
        {
            InitializeComponent();
        }

        private void calculate_Click(object sender, EventArgs e)
        {
            int age = int.Parse(inpAge.Text);
            int price = basicPrice;

            switch(age)
            {
                case < 5:
                    price -= basicPrice;
                    break;
                case >= 5 and <=12:
                    price /= 2;
                    break;
                case >= 55:
                    price -= basicPrice; 
                    break;
                default:
                    price = basicPrice;
                    break;
            }

            labPrice.Text = price.ToString("� 0.00");

        }
    }
}