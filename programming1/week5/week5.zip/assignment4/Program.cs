﻿namespace assignment4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[20];

            Console.Write("Enter a number (0=stop): ");
            int input = int.Parse(Console.ReadLine());
            int i = 0, count = 0;

            while (input != 0)
            {
                if (i < numbers.Length)
                    numbers[i] = input;

                i++;
                Console.Write("Enter a number (0=stop): ");
                input = int.Parse(Console.ReadLine());

            }
            Console.WriteLine();
            Console.Write("Enter a searchvalue: ");
            input = int.Parse(Console.ReadLine());

            for (int j = 0; j<numbers.Length; j++)
            {
                if (numbers[j] == input)
                    count++;
            }
            Console.WriteLine($"\nNumber of occurences of searchvalue ({input}) is: {count}");
        }
    }
}