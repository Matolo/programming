﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1
{
    public class Position
    {
        public int column;
        public int row;

        public Position(int row, int column)
        {
            this.column = column;
            this.row = row;
        }   
    }
}
