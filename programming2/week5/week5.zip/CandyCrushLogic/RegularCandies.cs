﻿using System;

namespace CandyCrushLogic
{
    public enum RegularCandies
    {
        JellyBean, Lozenge, LemonDrop, GumSquare, LollipopHead, JujubeCluster
    }
}
