﻿using System;


namespace assignment2
{
    internal class Position
    {
        public int row;
        public int column;
    }
}
