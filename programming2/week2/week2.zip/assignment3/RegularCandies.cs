﻿using System;

namespace assignment3
{
    public enum RegularCandies
    {
        JellyBean, Lozenge, LemonDrop, GumSquare, LollipopHead, JujubeCluster
    }
}
