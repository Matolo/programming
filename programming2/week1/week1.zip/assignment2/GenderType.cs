﻿namespace assignment2
{
    enum GenderType
    {
        Male, Female
    }
}
